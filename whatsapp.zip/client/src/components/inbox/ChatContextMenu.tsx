import { useMemo } from 'react';
import {
  Bot,
  CheckCircle2,
  Clock,
  PauseCircle,
  PlayCircle,
  UserMinus,
  UserPlus,
  XCircle,
} from 'lucide-react';
import ContextMenu, { type ContextMenuItem } from '../ui/ContextMenu';
import ContactAvatar from './ContactAvatar';
import type { Conversation, TeamAgent } from '../../types';

interface ChatContextMenuProps {
  open: boolean;
  x: number;
  y: number;
  conversation: Conversation | null;
  agents: TeamAgent[];
  currentUserId?: string;
  botIsLive: boolean;
  assigning: boolean;
  botToggling: boolean;
  onClose: () => void;
  onAssign: (agentId: string | null) => void;
  onToggleBot: () => void;
  onStatusChange: (status: string) => void;
}

export default function ChatContextMenu({
  open,
  x,
  y,
  conversation,
  agents,
  currentUserId,
  botIsLive,
  assigning,
  botToggling,
  onClose,
  onAssign,
  onToggleBot,
  onStatusChange,
}: ChatContextMenuProps) {
  const items = useMemo<ContextMenuItem[]>(() => {
    if (!conversation) return [];

    const assignedId = conversation.assignedAgent?.id;
    const assignChildren: ContextMenuItem[] = [
      {
        id: 'unassign',
        label: 'Unassigned',
        description: 'Remove agent assignment',
        icon: UserMinus,
        onClick: () => onAssign(null),
        disabled: assigning || !assignedId,
        checked: !assignedId,
      },
      ...agents
        .filter((agent) => agent.id !== currentUserId)
        .map((agent) => ({
        id: `agent-${agent.id}`,
        label: agent.name,
        description: agent.email,
        icon: UserPlus,
        onClick: () => onAssign(agent.id),
        disabled: assigning,
        checked: assignedId === agent.id,
      })),
    ];

    if (currentUserId && agents.some((agent) => agent.id === currentUserId)) {
      const me = agents.find((agent) => agent.id === currentUserId)!;
      assignChildren.unshift({
        id: 'assign-me',
        label: 'Assign to me',
        description: me.email,
        icon: UserPlus,
        onClick: () => onAssign(currentUserId),
        disabled: assigning,
        checked: assignedId === currentUserId,
      });
    }

    const status = conversation.status;

    return [
      {
        id: 'assign',
        label: 'Assign to',
        description: conversation.assignedAgent?.name || 'No agent assigned',
        icon: UserPlus,
        children: assignChildren,
      },
      {
        id: 'bot-toggle',
        label: botIsLive ? 'Pause AI bot' : 'Enable AI bot',
        description: botIsLive ? 'Stop auto-replies for this chat' : 'Resume auto-replies',
        icon: botIsLive ? PauseCircle : PlayCircle,
        onClick: onToggleBot,
        disabled: botToggling,
        checked: botIsLive,
      },
      { id: 'sep-1', label: '', separator: true },
      {
        id: 'status-open',
        label: 'Mark as open',
        icon: CheckCircle2,
        onClick: () => onStatusChange('OPEN'),
        disabled: status === 'OPEN',
        checked: status === 'OPEN',
      },
      {
        id: 'status-pending',
        label: 'Mark as pending',
        icon: Clock,
        onClick: () => onStatusChange('PENDING'),
        disabled: status === 'PENDING',
        checked: status === 'PENDING',
      },
      {
        id: 'status-closed',
        label: 'Mark as closed',
        icon: XCircle,
        onClick: () => onStatusChange('CLOSED'),
        disabled: status === 'CLOSED',
        checked: status === 'CLOSED',
        danger: status !== 'CLOSED',
      },
    ];
  }, [
    agents,
    assigning,
    botIsLive,
    botToggling,
    conversation,
    currentUserId,
    onAssign,
    onStatusChange,
    onToggleBot,
  ]);

  if (!conversation) return null;

  return (
    <ContextMenu
      open={open}
      x={x}
      y={y}
      onClose={onClose}
      header={
        <div className="flex items-center gap-3">
          <ContactAvatar
            name={conversation.contact.name}
            phone={conversation.contact.phone}
            size="sm"
          />
          <div className="min-w-0">
            <p className="truncate text-[13px] font-extrabold text-neutral-900">
              {conversation.contact.name || conversation.contact.phone}
            </p>
            <p className="truncate text-[11px] font-medium text-neutral-500">
              {conversation.contact.phone}
            </p>
          </div>
          <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-neutral-100 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-neutral-600 ring-1 ring-neutral-200/70">
            <Bot className="h-3 w-3" />
            Chat
          </span>
        </div>
      }
      items={items}
    />
  );
}
