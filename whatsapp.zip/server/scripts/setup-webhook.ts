import prisma from '../src/config/database';
import { MetaWhatsAppService } from '../src/modules/whatsapp/meta.service';
import { config } from '../src/config';
import logger from '../src/utils/logger';
import { logError } from '../src/errors';

async function main() {
  if (!config.meta.webhookUrl) {
    throw new Error('Set META_WEBHOOK_URL in server/.env first (HTTPS tunnel URL + /api/whatsapp/webhook)');
  }

  logger.info('Registering webhook', { webhookUrl: config.meta.webhookUrl });

  const number = await prisma.whatsappNumber.findFirst({ where: { isActive: true } });
  if (!number) throw new Error('No active WhatsApp number — connect WhatsApp in Settings first');

  const token = MetaWhatsAppService.decryptToken(number.accessToken);
  const result = await MetaWhatsAppService.configureWebhooks(number.wabaId, token);
  const status = await MetaWhatsAppService.getWebhookStatus(number.wabaId, token);

  logger.info('Webhook setup complete', { ...result, subscribed: status.subscribed });
}

main()
  .catch((err) => {
    logError(err, { source: 'startup', action: 'setup-webhook failed' });
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
